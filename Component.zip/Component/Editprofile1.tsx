import React from 'react';
import {View, Image,Text, StyleSheet,TextInput,SafeAreaView, Button, TouchableHighlight, ScrollView} from 'react-native';
import {useState} from 'react'
import DropDownPicker from 'react-native-dropdown-picker';


 
{/********/}

const Edit_profile_1 = ( props) => {

  const [text, onChangeText] = React.useState('Useless Text');
  const [number, onChangeNumber] = React.useState('');



  const [isOpen, setIsOpen] = useState(false);
  const [currentValue, setCurrentValue] = useState();

  const [isOpen1, setIsOpen1] = useState(false);
  const [currentValue1, setCurrentValue1] = useState();

  const [isOpen2, setIsOpen2] = useState(false);
  const [currentValue2, setCurrentValue2] = useState();

  
  const items=[
    { label:'Male', value:'Male'},
    {label: 'Female', value:'Female'},
    {label:'Other', value:'Other'}]

   
  const items1=[
    { label:'Single', value:'Single'},
  {label: 'Married', value:'Married'},
  {label: 'Divorced', value:'Divorced'}
]
  

  const items2=[
    { label:'MBBS', value:'MBBS'},
  {label: 'BAMS', value:'BAMS'}]
  

 
  

  

  
  
  return (

    <ScrollView>
    <View style={styles.container} >
    <View style={{ backgroundColor:'#BBE8E1', height:7, width:'100%', borderRadius:5, position:'relative'}}>
  <View style={{ backgroundColor:'#2DA0BE', height:7, width:'30%', borderRadius:5, position:'absolute'}}>

  </View>
 </View>

    <Text style={{ fontSize:15, color:'#242435', marginTop:10, fontWeight:'700'}}>Personal Information</Text>

<Text style={{ fontSize:13, color:'#242435', marginTop:20}}> First Name</Text>
<SafeAreaView>
<TextInput
        style={styles.input3}
        onChangeText={onChangeText}
        placeholder="Enter Name"
      
      />

<Text style={{ fontSize:13, color:'#242435', marginTop:30}}>Last Name</Text> 
      <TextInput
        style={styles.input3}
        onChangeText={onChangeText}
        placeholder="Enter Names"
      
      />
      
 <Text style={{ fontSize:13, color:'#242435', marginTop:30}}>Enter phone number</Text> 
 <TextInput
        style={styles.input3}
        onChangeText={onChangeNumber}
     
        placeholder="Phone number"
        keyboardType="numeric"
      />
<Text style={{ fontSize:13, color:'#242435', marginTop:30}}>Email</Text> 
<TextInput
        style={styles.input3}
   
        placeholder="Email"
      
      />  
     
        <View><Text style={{ fontSize:13, color:'#242435', marginTop:30}}> Gender</Text> 
      <DropDownPicker items={items}  dropDownDirection="TOP"
      open={isOpen}  style={styles. dropdown}
      setOpen={()=> setIsOpen(!isOpen)} 
      value={currentValue}
      setValue={(val)=>setCurrentValue(val)}
    
      maxHeight={200}
      placeholder='Select'
    /></View>
<Text style={{ fontSize:13, color:'#242435', marginTop:30}}>Date of Birth</Text> 
<TextInput
        style={styles.input}
        onChangeText={onChangeNumber}
     
        placeholder="DD/MM/YYY"
        keyboardType="numeric"
      />
   <Text style={{ fontSize:13, color:'#242435', marginTop:30}}>Marital Status</Text> 
      <DropDownPicker items={items1}  dropDownDirection="TOP"
      open={isOpen1}  style={styles. dropdown}
      setOpen={()=> setIsOpen1(!isOpen1)} 
      value={currentValue1}
      setValue={val=>setCurrentValue1(val)}
    
      maxHeight={200}
      placeholder='Select'
    />
      <Text style={{ fontSize:13, color:'#242435', marginTop:30}}> Current Location</Text> 
      <TextInput
        style={styles.input}
   
        placeholder="Enter Location"
      
      />

      <TextInput
        style={styles.input2}
   
        placeholder="Prefered Location"
      
      />

      <TextInput
        style={styles.input2}
   
        placeholder="Permanent Address"
      
      />
     
  </SafeAreaView>
 <Text  style={styles.buttonStyle}></Text>
<TouchableHighlight  onPress={()=> props.navigation.navigate("Edit_profile_first")}  style={styles.submit}>
  <Text  style={styles.submitineer}>Next</Text>
</TouchableHighlight>
 </View>
    </ScrollView>
   
  ); 
};


const styles = StyleSheet.create({
  container: {
    padding:28, backgroundColor:'#fff', flex:1,
  },
  

  input: {
    height: 40,
    marginTop:10,
    fontSize:17,
    borderRadius:10,
    borderColor:'rgba(36, 36, 53, 0.12);',
    borderWidth:1,
    zIndex:-9999,
    padding: 10,
  },

  input2: {
    height: 40,
    marginTop:30,
    fontSize:17,
    borderRadius:10,
    borderColor:'rgba(36, 36, 53, 0.12);',
    borderWidth:1,
    zIndex:-9999,
    padding: 10,
  },

  input3: {
    height: 40,
    marginTop:5,
    fontSize:17,
    borderRadius:10,
    borderColor:'rgba(36, 36, 53, 0.12);',
    borderWidth:1,
    zIndex:-9999,
    padding: 10,
    backgroundColor:'#F2F2F2',
  },

  buttonStyle: {

    marginTop: 30,


},
dropdown:{
  marginTop:10,

},
submit:{
  backgroundColor:'#2DA08E',
  borderRadius:10,
  marginTop: 0,
  fontSize:17,
  padding:15,
 

},

submitineer:{
  color:'#fff',
  textAlign:'center',

}


});


export default Edit_profile_1 ;
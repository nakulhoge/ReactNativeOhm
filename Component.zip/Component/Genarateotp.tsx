import React from 'react';
import {View, Image,Text, StyleSheet,TextInput,SafeAreaView, Button,TouchableHighlight} from 'react-native';

import FontAwesome from 'react-native-vector-icons/FontAwesome'

const Genarateotp= ( props ) => {
  const [text, onChangeText] = React.useState('Useless Text');
  const [number, onChangeNumber] = React.useState('');

  const flag =  require("../images/flag.jpeg")
  return (

<View style={styles.container} >

<Text style={{ fontSize:24, color:'#242435'}}>Enter mobile number</Text>
<Text style={{ fontSize:17, color:'#242435',marginTop:10}}>Please enter the mobile number associated with your account. We will send the OTP to this number.</Text>


<SafeAreaView>
<View style={styles.sectionstyle}>

  <Image  source={flag}  style={{ position:'absolute', left:10, top:35}} />

      <TextInput
        style={styles.input2} 
        onChangeText={onChangeNumber}
        maxLength={10}
        placeholder="+91 1234256734"
        keyboardType="numeric"
      />

<FontAwesome name='phone' size={24} style={ styles.im3} />

      </View>

    </SafeAreaView>

<Text  style={styles.buttonStyle}></Text>


<TouchableHighlight  onPress={()=>props.navigation.navigate("verification")}   style={styles.submit}>

<Text  style={styles.submitineer}>Generate OTP </Text>
</TouchableHighlight>




<Text  style={{ fontSize:17,marginTop:40,textAlign: 'center'}}>
        
   
        Or Log in with
       
        </Text>
        
        <View style={{alignContent:'center', position:'relative', marginTop:30,   borderRadius:10,
        borderColor:'rgba(36, 36, 53, 0.12);',
        borderWidth:1}}>

<Image style={styles.im2} source={require('../images/google.png')} />
        <Text style={{ textAlign:'center', padding:15}}>  Login with google </Text>


</View>

<View style={{alignContent:'center', position:'relative', marginTop:30,   borderRadius:10,
        borderColor:'rgba(36, 36, 53, 0.12);',
        borderWidth:1}}>

<Image style={styles.im2} source={require('../images/apple.png')} />
        <Text style={{ textAlign:'center', padding:15}}> Login with apple </Text>


</View>







   
    </View>

  );


  
};


const styles = StyleSheet.create({
  container: {
    padding:28,  backgroundColor:'#fff',  flex:1,
  },
  logo: {
   
    width: 241,
    height:40,
    left:50
    // position:'absolute',
    // top:350,
    // left:80
  },

  input: {
    height: 40,
    marginTop:30,
    fontSize:17,
    borderRadius:10,
    borderColor:'rgba(36, 36, 53, 0.12);',
    borderWidth:1,
    padding: 10,
  },

  buttonStyle: {

    marginTop: 30,


},

im2:{

  resizeMode:'stretch',
  position:'absolute',
  top:12,
  left:70,
},

im3:{

  resizeMode:'stretch',
  position:'absolute',
  top:40,
  right:10,
},

input2: {
  height: 40,
  marginTop:30,
  fontSize:17,
  borderRadius:10,
  borderColor:'rgba(36, 36, 53, 0.12);',
  borderWidth:1,
  flex:1,
  position:'relative',
 paddingLeft:60,
 paddingRight:30,
},

sectionstyle:{

  flexDirection:'row',
  justifyContent:'center',
  position:'relative'



},

submit:{
    backgroundColor:'#2DA08E',
    borderRadius:10,
    marginTop: 0,
    fontSize:17,
    padding:15,
   
  
  },
  
  submitineer:{
    color:'#fff',
    textAlign:'center',
  
  }


});


export default Genarateotp;
import React from 'react';
import {
  View,
  Image,
  Text,
  StyleSheet,
  TextInput,
  SafeAreaView,
  Button,
  TouchableHighlight,
  ScrollView,
} from 'react-native';
import {useState} from 'react';
import DropDownPicker from 'react-native-dropdown-picker';
import AntDesign from 'react-native-vector-icons/AntDesign';

export default function App(props) {
  const [isOpen, setIsOpen] = useState(false);
  const [currentValue, setCurrentValue] = useState();

  const [isOpen1, setIsOpen1] = useState(false);
  const [currentValue1, setCurrentValue1] = useState();

  const [isOpen2, setIsOpen2] = useState(false);
  const [currentValue2, setCurrentValue2] = useState();

  const [isOpen3, setIsOpen3] = useState(false);
  const [currentValue3, setCurrentValue3] = useState();

  const [isOpen4, setIsOpen4] = useState(false);
  const [currentValue4, setCurrentValue4] = useState();

  const [isOpen5, setIsOpen5] = useState(false);
  const [currentValue5, setCurrentValue5] = useState();

  const [isOpen6, setIsOpen6] = useState(false);
  const [currentValue6, setCurrentValue6] = useState();

  const [isOpen7, setIsOpen7] = useState(false);
  const [currentValue7, setCurrentValue7] = useState();

  const [isOpen8, setIsOpen8] = useState(false);
  const [currentValue8, setCurrentValue8] = useState();

  const [isOpen9, setIsOpen9] = useState(false);
  const [currentValue9, setCurrentValue9] = useState();

  const [isOpen10, setIsOpen10] = useState(false);
  const [currentValue10, setCurrentValue10] = useState();

  const [isOpen11, setIsOpen11] = useState(false);
  const [currentValue11, setCurrentValue11] = useState();


  
  const items = [
    {label: '5', value: '1'},
    {label: '4', value: '4'},
  ];

  const items1 = [
    {label: 'read', value: 'bxnmnm'},
    {label: 'm,m,m', value: 'bnnslkj;k'},
  ];
  const items2 = [
    {label: 'jnnk', value: '5687987'},
    {label: 'jhkjlkm', value: 'n,nlkjml'},
  ];
  const items3 = [
    {label: 'm,nn', value: 'nnmnm'},
    {label: 'Znhj', value: 'nmkkj'},
  ];
  const items4 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items5 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items6 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items7 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items8 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items9 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items10 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items11 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];

  return (
    <ScrollView>
      <View style={styles.container}>
        <View
          style={{
            backgroundColor: '#BBE8E1',
            height: 7,
            width: '100%',
            borderRadius: 5,
            position: 'relative',
          }}>
          <View
            style={{
              backgroundColor: '#2DA0BE',
              height: 7,
              width: '100%',
              borderRadius: 5,
              position: 'absolute',
            }}></View>
        </View>

        <Text
          style={{
            fontSize: 15,
            color: '#242435',
            marginTop: 10,
            fontWeight: '700',
          }}>
          Experince
        </Text>

        <Text style={{fontSize: 13, color: '#242435', marginTop: 20}}>
          Job Type
        </Text>
        <DropDownPicker
          items={items}
          style={styles.input3}
          dropDownDirection="TOP"
          open={isOpen}
          setOpen={() => setIsOpen(!isOpen)}
          value={currentValue}
          setValue={val => setCurrentValue(val)}
          maxHeight={200}
          autoScroll
          placeholder="Part Time"
        />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          Designation
        </Text>
        <DropDownPicker
          items={items11}
          style={{marginTop: 5}}
          dropDownDirection="TOP"
          open={isOpen11}
          setOpen={() => setIsOpen1(!isOpen11)}
          value={currentValue11}
          setValue={val => setCurrentValue11(val)}
          maxHeight={200}
          autoScroll
          placeholder=" Select"
        />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          Job Category
        </Text>
        <DropDownPicker
          items={items1}
          style={{marginTop: 5}}
          dropDownDirection="TOP"
          open={isOpen1}
          setOpen={() => setIsOpen1(!isOpen1)}
          value={currentValue1}
          setValue={val => setCurrentValue1(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          Total Experince In Year
        </Text>
        <DropDownPicker
          items={items2}
          style={{marginTop: 5}}
          dropDownDirection="TOP"
          open={isOpen2}
          setOpen={() => setIsOpen2(!isOpen2)}
          value={currentValue2}
          setValue={val => setCurrentValue2(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          In Month
        </Text>
        <DropDownPicker
          items={items3}
          style={{marginTop: 5}}
          dropDownDirection="TOP"
          open={isOpen3}
          setOpen={() => setIsOpen3(!isOpen3)}
          value={currentValue3}
          setValue={val => setCurrentValue3(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          Current CTC
        </Text>
        <TextInput style={styles.input3} placeholder="500000" />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          Expected CTC
        </Text>
        <TextInput style={styles.input3} placeholder="700000" />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          Present Employer
        </Text>
        <DropDownPicker
          items={items6}
          style={{marginTop: 5}}
          dropDownDirection="TOP"
          open={isOpen6}
          setOpen={() => setIsOpen6(!isOpen6)}
          value={currentValue6}
          setValue={val => setCurrentValue6(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          Current Orgination Type
        </Text>
        <DropDownPicker
          items={items7}
          style={styles.input3}
          dropDownDirection="TOP"
          open={isOpen7}
          setOpen={() => setIsOpen7(!isOpen7)}
          value={currentValue7}
          setValue={val => setCurrentValue7(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          Notice Period
        </Text>
        <DropDownPicker
          items={items8}
          style={{marginTop: 5}}
          dropDownDirection="TOP"
          open={isOpen8}
          setOpen={() => setIsOpen8(!isOpen8)}
          value={currentValue8}
          setValue={val => setCurrentValue8(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          Current Orgination Name
        </Text>

        <TextInput style={styles.input3} placeholder="Null" />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          functionality Area
        </Text>

        <DropDownPicker
          items={items9}
          style={{marginTop: 5}}
          dropDownDirection="TOP"
          open={isOpen9}
          setOpen={() => setIsOpen9(!isOpen9)}
          value={currentValue9}
          setValue={val => setCurrentValue9(val)}
          maxHeight={200}
          autoScroll
          placeholder="selct"
        />

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          Key Skills
        </Text>
        <TextInput style={styles.input3} />
        <Text
          style={{
            fontSize: 13,
            color: '#242435',
            marginBottom: 10,
            marginTop: 30,
          }}>
          License Number
        </Text>
        <TextInput style={styles.input} placeholder="License Number" />

        <View style={{flexDirection: 'row', marginTop: 30}}>
          <View style={{flex: 1}}>
            <Text style={{fontSize: 17, color: '#242435', marginTop: 10}}>
              Updated Resume{' '}
            </Text>
          </View>
          <View style={{flex: 1, marginLeft: -40}}>
            <Text>
              {' '}
              <AntDesign
                name="pluscircle"
                size={40}
                style={{marginTop: 0, justifyContent: 'flex-start'}}
              />
            </Text>
          </View>
        </View>

        <Text style={{marginTop: 20}}> Maximum upload file size: 20MB</Text>

        <TouchableHighlight
          onPress={() => props.navigation.navigate('Profile')}
          style={styles.submit}>
          <Text style={styles.submitineer}>Updated Profile</Text>
        </TouchableHighlight>
      </View>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: {
    padding: 28,
    backgroundColor: '#fff',
    flex: 1,
  },

  input: {
    height: 40,
    marginTop: 0,
    fontSize: 17,
    borderRadius: 10,
    borderColor: 'rgba(36, 36, 53, 0.12);',
    borderWidth: 1,
    zIndex: -9999,
    padding: 10,
  },

  input3: {
    height: 40,
    marginTop: 5,
    fontSize: 17,
    borderRadius: 10,
    borderColor: 'rgba(36, 36, 53, 0.12);',
    borderWidth: 1,
    zIndex: -9999,
    padding: 10,
    backgroundColor: '#F2F2F2',
  },

  buttonStyle: {
    marginTop: 30,
  },
  dropdown: {
    marginTop: 30,
  },
  submit: {
    backgroundColor: '#2DA08E',
    borderRadius: 10,
    marginTop: 30,
    fontSize: 17,
    padding: 15,
  },

  submitineer: {
    color: '#fff',
    textAlign: 'center',
  },
});

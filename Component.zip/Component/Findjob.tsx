import React from 'react';
import {
  View,
  Image,
  Text,
  StyleSheet,
  TextInput,
  SafeAreaView,
  Button,
  TouchableHighlight,
  ScrollView,
} from 'react-native';
import {useState} from 'react';
import DropDownPicker from 'react-native-dropdown-picker';
import Fontisto from 'react-native-vector-icons/Fontisto';
import Feather from 'react-native-vector-icons/Feather';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';

const Findjob = props => {
  const [text, onChangeText] = React.useState('Useless Text');
  const [number, onChangeNumber] = React.useState('');

  const [isOpen, setIsOpen] = useState(false);
  const [currentValue, setCurrentValue] = useState();

  const [isOpen1, setIsOpen1] = useState(false);
  const [currentValue1, setCurrentValue1] = useState();
  const [isOpen2, setIsOpen2] = useState(false);
  const [currentValue2, setCurrentValue2] = useState();

  const items = [
    {label: '5', value: '1'},
    {label: '4', value: '4'},
  ];

  const items1 = [
    {label: 'read', value: 'bxnmnm'},
    {label: 'm,m,m', value: 'bnnslkj;k'},
  ];
  const items2 = [
    {label: 'jnnk', value: '5687987'},
    {label: 'jhkjlkm', value: 'n,nlkjml'},
  ];

  return (
    <ScrollView>
      <View style={styles.container}>
        <Text
          style={{
            fontSize: 13,
            color: '#242435',
            marginTop: 10,
            marginBottom: 5,
          }}>
          Select your skills
        </Text>
        <TextInput style={styles.input3} onChangeText={onChangeText} />
        <Text
          style={{
            fontSize: 13,
            color: '#242435',
            marginTop: 10,
            marginBottom: 5,
          }}>
          Job Role
        </Text>
        <TextInput style={styles.input3} onChangeText={onChangeText} />
        <Text
          style={{
            fontSize: 13,
            color: '#242435',
            marginTop: 10,
            marginBottom: 5,
          }}>
          Hospital / Institutes
        </Text>
        <TextInput
          style={styles.input3}
          onChangeText={onChangeText}
          placeholder="KEM Hospital"
        />

        <Text
          style={{
            fontSize: 13,
            color: '#242435',
            marginTop: 30,
            marginBottom: 5,
          }}>
          Location
        </Text>
        <DropDownPicker
          items={items2}
          style={{marginTop: 0, marginBottom: 30, backgroundColor: '#F2F2F2'}}
          dropDownDirection="TOP"
          open={isOpen2}
          setOpen={() => setIsOpen2(!isOpen2)}
          value={currentValue2}
          setValue={val => setCurrentValue2(val)}
          maxHeight={200}
          autoScroll
          placeholder="Pune"
        />

        <TouchableHighlight
          onPress={() => props.navigation.navigate('JobDetail')}
          style={styles.submit}>
          <Text style={styles.submitineer}>Find Job</Text>
        </TouchableHighlight>

        <View style={{flexDirection: 'row', marginBottom: 20, marginTop: 30}}>
          <View style={{flex: 1}}>
            <Text style={{fontSize: 24, color: '#242435', marginTop: 0}}>
              Result{' '}
            </Text>
          </View>
          <View>
            <Text
              style={{
                textAlign: 'right',
                marginTop: 10,
                fontSize: 13,
                color: '#2DA08E',
              }}>
              {' '}
              View all{' '}
            </Text>
          </View>
        </View>

        <View style={styles.boxmain}>
          <View style={{flexDirection: 'row', flex: 1, position: 'relative'}}>
            <View
              style={{
                width: 80,
                height: 80,
                backgroundColor: '#ccc',
                borderRadius: 4,
              }}></View>
            <View>
              <Text
                style={{
                  fontSize: 17,
                  justifyContent: 'flex-end',
                  color: '#242435',
                  textAlign: 'center',
                  marginLeft: 15,
                }}>
                Cathlab Technician{' '}
                <Text>
                  {' '}
                  <Feather
                    name="bookmark"
                    size={16}
                    style={{color: '#231F20'}}
                  />{' '}
                </Text>
              </Text>
              <Text
                style={{
                  fontSize: 13,
                  color: '#242435',
                  marginTop: 5,
                  marginLeft: 18,
                }}>
                Lets find relevant for you
              </Text>
            </View>
          </View>

          <Text style={{fontSize: 13, color: '#242435', marginTop: 15}}>
            {' '}
            <Fontisto
              name="map-marker-alt"
              size={16}
              style={{color: '#2DA08E'}}
            />{' '}
            <Text style={{marginRight: 20}}> Banglore </Text>
          </Text>
          <Text style={{fontSize: 13, color: '#242435', marginTop: 5}}>
            Experince : 3-5 years
          </Text>
          <Text style={{fontSize: 13, color: '#242435', marginTop: 5}}>
            Job posted : (3 Days Ago)
          </Text>
          <Text style={{fontSize: 13, color: '#242435', marginTop: 5}}>
            Key Skills : Cathlab Technician
          </Text>

          <View style={{flexDirection: 'row', marginBottom: 10}}>
            <View>
              <Text
                style={{
                  fontSize: 15,
                  backgroundColor: '#F2F2F2',
                  marginTop: 10,
                  textAlign: 'justify',
                  borderRadius: 4,
                  padding: 10,
                  marginRight: 10,
                  borderRadius: 5,
                }}>
                Full Time{' '}
              </Text>
            </View>
            <View>
              <Text
                style={{
                  textAlign: 'justify',
                  marginTop: 10,
                  fontSize: 15,
                  backgroundColor: '#F2F2F2',
                  padding: 10,
                  marginRight: 10,
                  borderRadius: 5,
                }}>
                {' '}
                Urgent{' '}
              </Text>
            </View>
            <View>
              <Text
                style={{
                  textAlign: 'justify',
                  marginTop: 10,
                  fontSize: 15,
                  backgroundColor: '#F2F2F2',
                  padding: 10,
                  marginRight: 10,
                  borderRadius: 5,
                }}>
                {' '}
                Internship{' '}
              </Text>
            </View>
          </View>

          <View style={{flexDirection: 'row'}}>
            <View style={{flex: 1}}>
              <Text style={{fontSize: 11, color: '#2DA08E', marginTop: 20}}>
                Salary : 30,000 - 45,000 k
              </Text>
            </View>
            <View style={{flex: 1, top: 10, padding: 2}}>
              <TouchableHighlight style={styles.submit3}>
                <Text style={styles.submitineer}>View details</Text>
              </TouchableHighlight>
            </View>
          </View>
        </View>

        <View style={styles.boxmain}>
          <View style={{flexDirection: 'row', flex: 1, position: 'relative'}}>
            <View
              style={{
                width: 80,
                height: 80,
                backgroundColor: '#ccc',
                borderRadius: 4,
              }}></View>
            <View>
              <Text
                style={{
                  fontSize: 17,
                  justifyContent: 'flex-end',
                  color: '#242435',
                  textAlign: 'center',
                  marginLeft: 15,
                }}>
                Cathlab Technician{' '}
                <Text>
                  {' '}
                  <Feather
                    name="bookmark"
                    size={16}
                    style={{color: '#231F20'}}
                  />{' '}
                </Text>
              </Text>
              <Text
                style={{
                  fontSize: 13,
                  color: '#242435',
                  marginTop: 5,
                  marginLeft: 18,
                }}>
                Lets find relevant for you
              </Text>
            </View>
          </View>

          <Text style={{fontSize: 13, color: '#242435', marginTop: 15}}>
            {' '}
            <Fontisto
              name="map-marker-alt"
              size={16}
              style={{color: '#2DA08E'}}
            />{' '}
            <Text style={{marginRight: 20}}> Banglore </Text>
          </Text>
          <Text style={{fontSize: 13, color: '#242435', marginTop: 5}}>
            Experince : 3-5 years
          </Text>
          <Text style={{fontSize: 13, color: '#242435', marginTop: 5}}>
            Job posted : (3 Days Ago)
          </Text>
          <Text style={{fontSize: 13, color: '#242435', marginTop: 5}}>
            Key Skills : Cathlab Technician
          </Text>

          <View style={{flexDirection: 'row', marginBottom: 10}}>
            <View>
              <Text
                style={{
                  fontSize: 15,
                  backgroundColor: '#F2F2F2',
                  marginTop: 10,
                  textAlign: 'justify',
                  borderRadius: 4,
                  padding: 10,
                  marginRight: 10,
                  borderRadius: 5,
                }}>
                Full Time{' '}
              </Text>
            </View>
            <View>
              <Text
                style={{
                  textAlign: 'justify',
                  marginTop: 10,
                  fontSize: 15,
                  backgroundColor: '#F2F2F2',
                  padding: 10,
                  marginRight: 10,
                  borderRadius: 5,
                }}>
                {' '}
                Urgent{' '}
              </Text>
            </View>
            <View>
              <Text
                style={{
                  textAlign: 'justify',
                  marginTop: 10,
                  fontSize: 15,
                  backgroundColor: '#F2F2F2',
                  padding: 10,
                  marginRight: 10,
                  borderRadius: 5,
                }}>
                {' '}
                Internship{' '}
              </Text>
            </View>
          </View>

          <View style={{flexDirection: 'row'}}>
            <View style={{flex: 1}}>
              <Text style={{fontSize: 11, color: '#2DA08E', marginTop: 20}}>
                Salary : 30,000 - 45,000 k
              </Text>
            </View>
            <View style={{flex: 1, top: 10, padding: 2}}>
              <TouchableHighlight style={styles.submit3}>
                <Text style={styles.submitineer}>View details</Text>
              </TouchableHighlight>
            </View>
          </View>
        </View>
        <View style={styles.boxmain}>
          <View style={{flexDirection: 'row', flex: 1, position: 'relative'}}>
            <View
              style={{
                width: 80,
                height: 80,
                backgroundColor: '#ccc',
                borderRadius: 4,
              }}></View>
            <View>
              <Text
                style={{
                  fontSize: 17,
                  justifyContent: 'flex-end',
                  color: '#242435',
                  textAlign: 'center',
                  marginLeft: 15,
                }}>
                Cathlab Technician{' '}
                <Text>
                  {' '}
                  <Feather
                    name="bookmark"
                    size={16}
                    style={{color: '#231F20'}}
                  />{' '}
                </Text>
              </Text>
              <Text
                style={{
                  fontSize: 13,
                  color: '#242435',
                  marginTop: 5,
                  marginLeft: 18,
                }}>
                Lets find relevant for you
              </Text>
            </View>
          </View>

          <Text style={{fontSize: 13, color: '#242435', marginTop: 15}}>
            {' '}
            <Fontisto
              name="map-marker-alt"
              size={16}
              style={{color: '#2DA08E'}}
            />{' '}
            <Text style={{marginRight: 20}}> Banglore </Text>
          </Text>
          <Text style={{fontSize: 13, color: '#242435', marginTop: 5}}>
            Experince : 3-5 years
          </Text>
          <Text style={{fontSize: 13, color: '#242435', marginTop: 5}}>
            Job posted : (3 Days Ago)
          </Text>
          <Text style={{fontSize: 13, color: '#242435', marginTop: 5}}>
            Key Skills : Cathlab Technician
          </Text>

          <View style={{flexDirection: 'row', marginBottom: 10}}>
            <View>
              <Text
                style={{
                  fontSize: 15,
                  backgroundColor: '#F2F2F2',
                  marginTop: 10,
                  textAlign: 'justify',
                  borderRadius: 4,
                  padding: 10,
                  marginRight: 10,
                  borderRadius: 5,
                }}>
                Full Time{' '}
              </Text>
            </View>
            <View>
              <Text
                style={{
                  textAlign: 'justify',
                  marginTop: 10,
                  fontSize: 15,
                  backgroundColor: '#F2F2F2',
                  padding: 10,
                  marginRight: 10,
                  borderRadius: 5,
                }}>
                {' '}
                Urgent{' '}
              </Text>
            </View>
            <View>
              <Text
                style={{
                  textAlign: 'justify',
                  marginTop: 10,
                  fontSize: 15,
                  backgroundColor: '#F2F2F2',
                  padding: 10,
                  marginRight: 10,
                  borderRadius: 5,
                }}>
                {' '}
                Internship{' '}
              </Text>
            </View>
          </View>

          <View style={{flexDirection: 'row'}}>
            <View style={{flex: 1}}>
              <Text style={{fontSize: 11, color: '#2DA08E', marginTop: 20}}>
                Salary : 30,000 - 45,000 k
              </Text>
            </View>
            <View style={{flex: 1, top: 10, padding: 2}}>
              <TouchableHighlight style={styles.submit3}>
                <Text style={styles.submitineer}>View details</Text>
              </TouchableHighlight>
            </View>
          </View>
        </View>
      </View>

      <View style={{flexDirection: 'row', marginBottom: 10, marginLeft: 16}}>
        <View style={{marginRight: 10}}>
          <Text
            onPress={() => props.navigation.navigate('Signup')}
            style={{fontSize: 17, marginLeft: 11, marginTop: 20}}>
            {' '}
            <Ionicons name="home-outline" size={24} />{' '}
          </Text>

          <Text
            onPress={() => props.navigation.navigate('Signup')}
            style={{
              textAlign: 'justify',
              marginTop: 0,
              fontSize: 10,
              backgroundColor: '#F2F2F2',
              padding: 10,
              borderRadius: 5,
            }}>
            {' '}
            Home{' '}
          </Text>
        </View>
        <View>
          <Text
            style={{marginRight: 10}}
            onPress={() => props.navigation.navigate('Findjob')}
            style={{fontSize: 17, marginLeft: 16, marginTop: 20}}>
            {' '}
            <Ionicons name="bag-outline" size={24} />{' '}
          </Text>

          <Text
            style={{marginRight: 10}}
            onPress={() => props.navigation.navigate('Findjob')}
            style={{
              textAlign: 'justify',
              marginTop: 0,
              fontSize: 10,
              backgroundColor: '#F2F2F2',
              padding: 10,
              borderRadius: 5,
            }}>
            {' '}
            Find Job{' '}
          </Text>
        </View>
        <View>
          <Text
            onPress={() => props.navigation.navigate('JobApplied')}
            style={{fontSize: 17, marginLeft: 19, marginTop: 20}}>
            {' '}
            <MaterialCommunityIcons
              name="application-cog-outline"
              size={24}
            />{' '}
          </Text>

          <Text
            onPress={() => props.navigation.navigate('JobApplied')}
            style={{
              textAlign: 'justify',
              marginTop: 0,
              fontSize: 10,
              backgroundColor: '#F2F2F2',
              padding: 10,
              marginRight: 10,
              borderRadius: 5,
            }}>
            {' '}
            Job Applied{' '}
          </Text>
        </View>
        <View>
          <Text
            onPress={() => props.navigation.navigate('Inbox')}
            style={{fontSize: 17, marginLeft: 11, marginTop: 20}}>
            {' '}
            <MaterialCommunityIcons name="inbox-outline" size={24} />{' '}
          </Text>

          <Text
            onPress={() => props.navigation.navigate('Inbox')}
            style={{
              textAlign: 'justify',
              marginTop: 0,
              fontSize: 10,
              backgroundColor: '#F2F2F2',
              padding: 10,
              marginRight: 10,
              borderRadius: 5,
            }}>
            {' '}
            Inbox{' '}
          </Text>
        </View>
        <View>
          <Text
            onPress={() => props.navigation.navigate('Profile')}
            style={{fontSize: 17, marginLeft: 16, marginTop: 20}}>
            {' '}
            <MaterialCommunityIcons
              name="account-circle-outline"
              size={24}
            />{' '}
          </Text>

          <Text
            onPress={() => props.navigation.navigate('Profile')}
            style={{
              textAlign: 'justify',
              marginTop: 0,
              fontSize: 10,
              backgroundColor: '#F2F2F2',
              padding: 10,
              marginRight: 10,
              borderRadius: 5,
            }}>
            {' '}
            Profile{' '}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};
const styles = StyleSheet.create({
  container: {
    padding: 28,
    backgroundColor: '#fff',
    flex: 1,
  },

  input: {
    height: 40,
    marginTop: 0,
    fontSize: 17,
    borderRadius: 10,
    borderColor: 'rgba(36, 36, 53, 0.12);',
    borderWidth: 1,
    zIndex: -9999,
    padding: 10,
  },

  buttonStyle: {
    marginTop: 30,
  },
  dropdown: {
    marginTop: 30,
  },
  submit: {
    backgroundColor: '#2DA08E',
    borderRadius: 10,
    marginTop: 20,
    fontSize: 17,
    padding: 15,
  },

  boxmain: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 20,
    borderRadius: 5,
    marginBottom: 20,
  },

  submitineer: {
    color: '#fff',
    textAlign: 'center',
  },
  input3: {
    height: 40,
    marginTop: 5,
    fontSize: 17,
    borderRadius: 10,
    borderColor: 'rgba(36, 36, 53, 0.12);',
    borderWidth: 1,
    zIndex: -9999,
    padding: 10,
    backgroundColor: '#F2F2F2',
  },

  submit3: {
    backgroundColor: '#2DA08E',
    borderRadius: 5,
    marginTop: 0,
    fontSize: 17,
    padding: 10,
    width: 125,
    marginLeft: 20,
  },
});

export default Findjob;

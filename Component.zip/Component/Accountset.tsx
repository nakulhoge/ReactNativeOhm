import React from 'react';
import {View, Image,Text, StyleSheet,TextInput,SafeAreaView, Button, TouchableHighlight, ScrollView} from 'react-native';
import {useState} from 'react'
import DropDownPicker from 'react-native-dropdown-picker';


 


const AccountSet = ( props ) => {
  const [text, onChangeText] = React.useState('Useless Text');
  const [number, onChangeNumber] = React.useState('');



  const [isOpen, setIsOpen] = useState(false);
  const [currentValue, setCurrentValue] = useState();
  const items=[
    { label:'Active', value:'Active'},
  {label: 'Inactive', value:'Inactive'}]
  
  return (
<ScrollView>
<View style={styles.container} >
<Text style={{ fontSize:24, color:'#242435'}}>Account Status</Text>
<SafeAreaView>
<Text style={{ fontSize:17, color:'#242435', marginTop:20}}>Email</Text> 
<TextInput
        style={styles.input}
         placeholder="Email"
      />  
    
<View><Text style={{ fontSize:16, color:'#242435',marginTop:20}}>Status</Text></View>

<DropDownPicker items={items}  dropDownDirection="TOP"
  open={isOpen}  style={styles. dropdown}
  setOpen={()=> setIsOpen(!isOpen)} 
  value={currentValue}
  setValue={val=>setCurrentValue(val)}
  maxHeight={200}
 
  placeholder='status'
  /> 
     
   
    
    
  </SafeAreaView>
 <Text  style={styles.buttonStyle}></Text>
<TouchableHighlight  onPress={()=>props.navigation.navigate("Inbox")}  style={styles.submit}>
  <Text  style={styles.submitineer}>Update Status</Text>
</TouchableHighlight>
 </View>
 
    </ScrollView>
   
  ); 
};


const styles = StyleSheet.create({
  container: {
    padding:28, backgroundColor:'#fff', flex:1,
  },
  

  input: {
    height: 40,
    marginTop:10,
    fontSize:17,
    borderRadius:10,
    borderColor:'rgba(36, 36, 53, 0.12);',
    borderWidth:1,
    zIndex:-9999,
  
    padding: 10,
  },

  buttonStyle: {

    marginTop: 30,


},
dropdown:{
  marginTop:10,

},
submit:{
  backgroundColor:'#2DA08E',
  borderRadius:10,
  marginTop: 0,
  fontSize:20,
  padding:15,
 

},

submitineer:{
  color:'#fff',
  textAlign:'center',

}


});


export default AccountSet ;
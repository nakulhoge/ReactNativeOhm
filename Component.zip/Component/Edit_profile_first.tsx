import React,{useState,useEffect} from 'react';
import {
  View,
  Image,
  Text,
  StyleSheet,
  TextInput,
  SafeAreaView,
  Button,
  TouchableHighlight,
  ScrollView,
} from 'react-native';

import DropDownPicker from 'react-native-dropdown-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';




const  App=(props)=> {
 
  const [isOpen, setIsOpen] = useState(false);
  const [currentValue, setCurrentValue] = useState();

  const [isOpen1, setIsOpen1] = useState(false);
  const [currentValue1, setCurrentValue1] = useState();
  const [isOpen2, setIsOpen2] = useState(false);
  const [currentValue2, setCurrentValue2] = useState();
  const [isOpen3, setIsOpen3] = useState(false);
  const [currentValue3, setCurrentValue3] = useState();
  const [isOpen4, setIsOpen4] = useState(false);
  const [currentValue4, setCurrentValue4] = useState();
  const [isOpen5, setIsOpen5] = useState(false);
  const [currentValue5, setCurrentValue5] = useState();
  const [isOpen6, setIsOpen6] = useState(false);
  const [currentValue6, setCurrentValue6] = useState();
  const [isOpen7, setIsOpen7] = useState(false);
  const [currentValue7, setCurrentValue7] = useState();
  const [isOpen8, setIsOpen8] = useState(false);
  const [currentValue8, setCurrentValue8] = useState();
  const [isOpen9, setIsOpen9] = useState(false);
  const [currentValue9, setCurrentValue9] = useState();
  const [isOpen10, setIsOpen10] = useState(false);
  const [currentValue10, setCurrentValue10] = useState();
  const [isOpen11, setIsOpen11] = useState(false);
  const [currentValue11, setCurrentValue11] = useState();
  const [tokens, setTokens] = useState('');

  const getToken = async () => {
    try {
      // Retrieve the token from AsyncStorage
      const storedToken = await AsyncStorage.getItem('userToken');

      // Check if the token is present
      if (storedToken) {
        console.log('Token found in AsyncStorage:', storedToken);
        setTokens(storedToken);
        // You can perform additional actions here if needed
      } else {
        console.warn('Token not found in AsyncStorage');
      }
    } catch (error) {
      console.error('Error while getting token:', error);
    }
  };

  // Call the function to get the token when the component mounts

  useEffect(() => {
    setTimeout(() => {
      getToken();
    }, 2000);
  }, []);
console.log(tokens)

  const items = [
    {label: '5', value: '1'},
    {label: '4', value: '4'},
  ];

  const items1 = [
    {label: 'read', value: 'bxnmnm'},
    {label: 'm,m,m', value: 'bnnslkj;k'},
  ];
  const items2 = [
    {label: 'jnnk', value: '5687987'},
    {label: 'jhkjlkm', value: 'n,nlkjml'},
  ];
  const items3 = [
    {label: 'm,nn', value: 'nnmnm'},
    {label: 'Znhj', value: 'nmkkj'},
  ];
  const items4 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items5 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items6 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items7 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items8 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items9 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items10 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];
  const items11 = [
    {label: 'cnbnb', value: 'jjjjj'},
    {label: 'nnnnnn', value: 'jkllkk'},
  ];

  return (
    <ScrollView>
      <View style={styles.container}>
        <View
          style={{
            backgroundColor: '#BBE8E1',
            height: 7,
            width: '100%',
            borderRadius: 5,
            position: 'relative',
          }}>
          <View
            style={{
              backgroundColor: '#2DA0BE',
              height: 7,
              width: '60%',
              borderRadius: 5,
              position: 'absolute',
            }}></View>
        </View>

        <Text
          style={{
            fontSize: 15,
            color: '#242435',
            marginTop: 10,
            fontWeight: '700',
          }}>
          Qualification
        </Text>

        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          NABH/NABL/JCL Protocol
        </Text>
        <DropDownPicker
          items={items11}
          style={{marginTop: 10}}
          dropDownDirection="TOP"
          open={isOpen11}
          setOpen={() => setIsOpen1(!isOpen11)}
          value={currentValue11}
          setValue={val => setCurrentValue11(val)}
          maxHeight={200}
          autoScroll
          placeholder=" select"
        />
        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          Job Category
        </Text>
        <DropDownPicker
          items={items1}
          style={{marginTop: 10}}
          dropDownDirection="TOP"
          open={isOpen1}
          setOpen={() => setIsOpen1(!isOpen1)}
          value={currentValue1}
          setValue={val => setCurrentValue1(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />
        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          Graduation
        </Text>
        <DropDownPicker
          items={items2}
          style={{marginTop: 10}}
          dropDownDirection="TOP"
          open={isOpen2}
          setOpen={() => setIsOpen2(!isOpen2)}
          value={currentValue2}
          setValue={val => setCurrentValue2(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />
        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          Post Graduation
        </Text>
        <DropDownPicker
          items={items3}
          style={{marginTop: 10}}
          dropDownDirection="TOP"
          open={isOpen3}
          setOpen={() => setIsOpen3(!isOpen3)}
          value={currentValue3}
          setValue={val => setCurrentValue3(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />
        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          Deperment
        </Text>
        <DropDownPicker
          items={items4}
          style={{marginTop: 10}}
          dropDownDirection="TOP"
          open={isOpen4}
          setOpen={() => setIsOpen4(!isOpen4)}
          value={currentValue4}
          setValue={val => setCurrentValue4(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />
        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          Functional Area
        </Text>
        <DropDownPicker
          items={items5}
          style={{marginTop: 10}}
          dropDownDirection="TOP"
          open={isOpen5}
          setOpen={() => setIsOpen5(!isOpen5)}
          value={currentValue5}
          setValue={val => setCurrentValue5(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />
        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          College
        </Text>
        <TextInput style={styles.input3} placeholder="Pune" />
        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          University
        </Text>
        <TextInput style={styles.input3} placeholder="University" />
        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          Pasing Year
        </Text>

        <TextInput style={styles.input3} placeholder="2019" />
        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          fellowship Area
        </Text>

        <DropDownPicker
          items={items9}
          style={styles.input3}
          dropDownDirection="TOP"
          open={isOpen9}
          setOpen={() => setIsOpen9(!isOpen9)}
          value={currentValue9}
          setValue={val => setCurrentValue9(val)}
          maxHeight={200}
          autoScroll
          placeholder="select"
        />
        <Text style={{fontSize: 13, color: '#242435', marginTop: 30}}>
          {' '}
          Certification
        </Text>
        <DropDownPicker
          items={items10}
          style={styles.input3}
          dropDownDirection="TOP"
          open={isOpen10}
          setOpen={() => setIsOpen10(!isOpen10)}
          value={currentValue10}
          setValue={val => setCurrentValue10(val)}
          maxHeight={200}
          autoScroll
          placeholder="Select"
        />
        <TouchableHighlight
        
          onPress={() => props.navigation.navigate('Edit_profile_second')}
          style={styles.submit}>
          <Text style={styles.submitineer}>Next</Text>
        </TouchableHighlight>
      </View>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: {
    padding: 28,
    backgroundColor: '#fff',
    flex: 1,
  },

  input: {
    height: 40,
    marginTop: 0,
    fontSize: 17,
    borderRadius: 10,
    borderColor: 'rgba(36, 36, 53, 0.12);',
    borderWidth: 1,
    zIndex: -9999,
    padding: 10,
  },

  buttonStyle: {
    marginTop: 30,
  },
  dropdown: {
    marginTop: 30,
  },
  submit: {
    backgroundColor: '#2DA08E',
    borderRadius: 10,
    marginTop: 30,
    fontSize: 17,
    padding: 15,
  },

  input3: {
    height: 40,
    marginTop: 5,
    fontSize: 17,
    borderRadius: 10,
    borderColor: 'rgba(36, 36, 53, 0.12);',
    borderWidth: 1,
    zIndex: -9999,
    padding: 10,
    backgroundColor: '#F2F2F2',
  },

  submitineer: {
    color: '#fff',
    textAlign: 'center',
  },
});
export default App;